/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package supermercado;

/**
 *
 * @author boris
 */
import java.util.*;

class Producto {
    private String nombre;
    private float precio;
    private Date fechaCaducidad;
    private int inventario;
    private int cantidadProducto;

    public Producto(String nombre, float precio, Date fechaCaducidad, int inventario) {
        this.nombre = nombre;
        this.precio = precio;
        this.fechaCaducidad = fechaCaducidad;

        this.inventario = inventario;
    }

    public Producto(String nombre, float precio, int cantidadProducto) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidadProducto = cantidadProducto;
    }

    public int getCantidadProducto() {
        return cantidadProducto;
    }
    
    
    

    public boolean comprar(int cantidad) {
        if (cantidad <= inventario) {
            inventario -= cantidad;
            return true;
        }
        return false;
    }

    public float precioTotal(int cantidad) {
        return cantidad * precio;
    }

    public void actualizarCantidad(int nuevaCantidad) {
        this.inventario = nuevaCantidad;
    }

    public boolean productoVencido() {
        Date hoy = new Date();
        return fechaCaducidad.before(hoy);
    }

    public void mostrarInformacion() {
        System.out.println("Producto: " + nombre + ", Precio: " + precio);
    }

        public String getNombre() {
        return nombre;
    }

    public float getPrecio() {
        return precio;
    }
}