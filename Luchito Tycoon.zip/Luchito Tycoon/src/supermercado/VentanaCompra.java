/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package supermercado;


import java.awt.BorderLayout;
import static javax.swing.GroupLayout.Alignment.CENTER;
import supermercado.Cliente;
import supermercado.Producto;
import supermercado.VentanaInicio;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class VentanaCompra extends JFrame {
    public VentanaCompra(Cliente cliente, String nombreProducto, String precioUnitarioStr) {
        this.setTitle("Confirmar compra");
        setSize(300, 200);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setLocationRelativeTo(null);

        double precioUnitario = Double.parseDouble(precioUnitarioStr.replace("$", ""));

        JComboBox<Integer> cantidadProducto = new JComboBox<>();
        for (int i = 1; i <= 10; i++) {
            cantidadProducto.addItem(i);
        }

        JLabel lblMensaje = new JLabel("Deseas comprar " + cantidadProducto.getSelectedItem() + " de " + nombreProducto + " a $" + precioUnitario + "?");

        cantidadProducto.addActionListener(e -> {
            int cantidad = (int) cantidadProducto.getSelectedItem();
            Producto producto1 = new Producto(nombreProducto, (float) precioUnitario, cantidad);
            double precioTotal = cantidad * precioUnitario;

            lblMensaje.setText("Deseas comprar " + cantidad + " de " + nombreProducto + " a $" + precioTotal + "?");
        });
            
        
        
        JButton btnConfirmar = new JButton("Confirmar");
        btnConfirmar.addActionListener(e -> {
            int cantidad = (int) cantidadProducto.getSelectedItem();
            Producto producto1 = new Producto(nombreProducto, (float) precioUnitario, cantidad);
            cliente.agregarProducto(producto1);
            JOptionPane.showMessageDialog(this, "Añadido al carrito");
            dispose();
        });

        this.setLayout(new BorderLayout());
        JPanel panelCentral = new JPanel();
        panelCentral.add(cantidadProducto);
        panelCentral.add(lblMensaje);

        this.add(panelCentral, BorderLayout.CENTER);
        this.add(btnConfirmar, BorderLayout.SOUTH);
        this.setVisible(true);
    }
}