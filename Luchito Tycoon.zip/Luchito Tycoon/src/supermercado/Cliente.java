/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package supermercado;

import java.util.List;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author boris
 */
public class Cliente {
    private static Cliente instancia;
    
    private String nombre;
    private int idCliente;
    private Date fechaCompra;
    private List<Producto> carrito;

    public Cliente(String nombre, int idCliente) {
        this.nombre = nombre;
        this.idCliente = idCliente;
        this.carrito = new ArrayList<>();
    }

    public List<Producto> getCarrito() {
        return carrito;
    }

    
    
    public void agregarProducto(Producto producto) {
        carrito.add(producto);
    }

    public void eliminarProducto(Producto producto) {
        carrito.remove(producto);
    }

    public float calcularCostoFinal() {
        float total = 0;
        for (Producto p : carrito) {
            total += p.precioTotal(p.getCantidadProducto());
        }
        return total;
    }

    public void leerFactura(Factura factura) {
        factura.mostrarDetalles();
    }

    public String getNombre() {
        return nombre;
    }

    public int getIdCliente() {
        return idCliente;
    }

   
    
}
