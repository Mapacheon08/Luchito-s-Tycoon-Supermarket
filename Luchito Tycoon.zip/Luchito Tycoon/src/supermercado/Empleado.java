/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package supermercado;


public class Empleado {
    private int idEmpleado;
    private String nombre;
    private String cargo;

    public Empleado(String nombre, int idEmpleado, String cargo) {
        this.idEmpleado = idEmpleado;
        this.nombre = nombre;
        this.cargo = cargo;
    }

    public void atenderCliente(Cliente cliente) {
        System.out.println("Atendiendo al cliente: " + cliente);
    }

    public void gestionarInventario(Producto producto, int cantidad) {
        producto.actualizarCantidad(cantidad);
    }
}
