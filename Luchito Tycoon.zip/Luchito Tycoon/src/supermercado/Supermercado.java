
package supermercado;

import java.util.Date;
import supermercado.Producto;

public class Supermercado {
    public static void main(String[] args) {
    new VentanaInicio();
    
    // inventario carnes
    Producto churrascoTotal = new Producto("churrasco (por libra)", 24000, new Date(), 150);
    Producto costillasCerdoTotal = new Producto("costillas de cerdo (por kilo)", 22800, new Date(), 130);
    Producto lomoResTotal = new Producto("lomo de res (por 750g)", 48375, new Date(), 145);
    Producto pechugaPolloTotal = new Producto("pechuga de pollo (por libra)", 9000, new Date(), 210);
    
    // inventario lácteos
    Producto lecheEnteraTotal = new Producto("leche entera (por litro)", 6190, new Date(), 98);
    Producto quesitoTotal = new Producto("quesito (por libra)", 8500, new Date(), 78);
    Producto yogurtTotal = new Producto("yogurt (1700g)", 23900, new Date(), 67);
    Producto mantequillaTotal = new Producto("mantequilla (250g)", 15400, new Date(), 89);
    
    // inventario verduras
    Producto zanahoriaTotal = new Producto("zanahoria (por libra)", 2190, new Date(), 90);
    Producto tomateTotal = new Producto("tomate (por libra)", 2290, new Date(), 57);
    Producto habichuelaTotal = new Producto("habichuela (por libra)", 3390, new Date(), 49);
    Producto zucchiniTotal = new Producto("zucchini (por libra)", 2130, new Date(), 78);
    
    // inventario frutas
    Producto manzanaTotal = new Producto("manzana (por libra)", 4234, new Date(), 88);
    Producto tomateArbolTotal = new Producto("tomate de árbol (por kilo)", 7546, new Date(), 77);
    Producto bananoTotal = new Producto("banano (por libra)", 2130, new Date(), 89);
    Producto fresaTotal = new Producto("fresa (por libra)", 5234, new Date(), 78);
    
}
}
