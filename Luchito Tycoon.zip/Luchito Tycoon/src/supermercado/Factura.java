/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package supermercado;

import java.util.Date;

/**
 *
 * @author boris
 */
class Factura {
    private int idFactura;
    private Date fecha;
    private float total;

    public Factura(int idFactura, float total) {
        this.idFactura = idFactura;
        this.fecha = new Date();
        this.total = total;
    }

    public void mostrarDetalles() {
        System.out.println("Factura ID: " + idFactura + ", Fecha: " + fecha + ", Total: " + total);
    }
}