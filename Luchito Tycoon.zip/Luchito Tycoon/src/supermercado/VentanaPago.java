/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package supermercado;


import java.awt.Color;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;
import supermercado.Producto;
import supermercado.Cliente;

public class VentanaPago extends JFrame {
    public VentanaPago(Cliente cliente){
        this.setTitle("Carrito");
        setSize(450, 400);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setLayout(null);
        
        JLayeredPane layeredPane = getLayeredPane();
        
        JPanel colorFondo = new JPanel();
        colorFondo.setBounds(0, 0, this.getWidth(), this.getHeight());
        colorFondo.setBackground(new Color(192, 192, 255));
        layeredPane.add(colorFondo, Integer.valueOf(1));
        
        // factura titulo
        JLabel facturaProductos = new JLabel("Factura para:");
        facturaProductos.setBounds(35, 45, 150, 20);
        facturaProductos.setFont(new Font("Comic Sans MS", 1, 12));
        facturaProductos.setOpaque(true);
        facturaProductos.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        facturaProductos.setBackground(Color.LIGHT_GRAY);
        layeredPane.add(facturaProductos, Integer.valueOf(2));
        
        // id titulo
        JLabel idProductos = new JLabel("id:");
        idProductos.setBounds(35, 65, 150, 20);
        idProductos.setFont(new Font("Comic Sans MS", 1, 12));
        idProductos.setOpaque(true);
        idProductos.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        idProductos.setBackground(Color.LIGHT_GRAY);
        layeredPane.add(idProductos, Integer.valueOf(2));
        
        // nombre cliente titulo
        JLabel nombreCliente = new JLabel(cliente.getNombre());
        nombreCliente.setBounds(185, 45, 150, 20);
        nombreCliente.setFont(new Font("Comic Sans MS", 1, 12));
        nombreCliente.setOpaque(true);
        nombreCliente.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        nombreCliente.setBackground(Color.LIGHT_GRAY);
        layeredPane.add(nombreCliente, Integer.valueOf(2));
        
        // id numero titulo
        JLabel idCliente = new JLabel(Integer.toString(cliente.getIdCliente()));
        idCliente.setBounds(185, 65, 150, 20);
        idCliente.setFont(new Font("Comic Sans MS", 1, 12));
        idCliente.setOpaque(true);
        idCliente.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        idCliente.setBackground(Color.LIGHT_GRAY);
        layeredPane.add(idCliente, Integer.valueOf(2));
    
        // productos
        int distanciaY = 85;
        for (Producto producto : cliente.getCarrito()) {
            JLabel detalleProducto = new JLabel(producto.getNombre() + " - $" + producto.getPrecio() * producto.getCantidadProducto() + " (" + producto.getCantidadProducto() + ")");
            detalleProducto.setBounds(35, distanciaY, 300, 20);
            detalleProducto.setFont(new Font("Comic Sans MS", 1, 12));
            detalleProducto.setOpaque(true);
            detalleProducto.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
            detalleProducto.setBackground(Color.WHITE);
            layeredPane.add(detalleProducto, Integer.valueOf(2));
            distanciaY += 20;
        }
   /*     System.out.println("Carrito actual:");
for (Producto p : cliente.getCarrito()) {
    System.out.println(p.getNombre() + " - Cantidad: " + p.getCantidadProducto());
}
        for (Producto p : cliente.getCarrito()) {
    System.out.println(p.getNombre() + " - Cantidad: " + p.getCantidadProducto());
}*/
        // total
        JLabel totalLabel = new JLabel("Total: $" + cliente.calcularCostoFinal());
        totalLabel.setBounds(35, distanciaY, 300, 20);
        totalLabel.setFont(new Font("Comic Sans MS", 1, 12));
        totalLabel.setOpaque(true);
        totalLabel.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        totalLabel.setBackground(Color.LIGHT_GRAY);
        layeredPane.add(totalLabel, Integer.valueOf(2));
        //distanciaY += 30;
        
        // boton pagar
        JButton botonPagar = new JButton("PAGAR");
        botonPagar.setBounds(35, 300, 100, 30);
        botonPagar.setBackground(new java.awt.Color(102, 255, 102));
        botonPagar.setOpaque(true);
        botonPagar.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        layeredPane.add(botonPagar, Integer.valueOf(2));
        
        this.setVisible(true);
    }
    
    
 /*public static void main(String[] args) {
   Cliente cliente = new Cliente("Cliente Prueba", 123); // Cliente de prueba
   cliente.agregarProducto(new Producto("Manzana", 4234, 3));
   cliente.agregarProducto(new Producto("Churrasco", 24000, 2));
   cliente.agregarProducto(new Producto("Leche Entera", 6190, 1));
   VentanaPago ventana = new VentanaPago(cliente);
   ventana.setVisible(true);
 }*/
 
}
