
package supermercado;


import java.awt.Color;
import java.awt.Image;
import supermercado.Cliente;
import supermercado.Empleado;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import java.awt.Font;
import javax.swing.JPanel;
import javax.swing.JTextField;



public class VentanaInicio extends JFrame {

      public VentanaInicio() {
        this.setTitle("Supermercado");
        this.setSize(500, 400);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setLayout(null);

        JLayeredPane layeredPane = getLayeredPane();

        // Imagen de fondo
        ImageIcon image = new ImageIcon("C:\\Users\\boris\\OneDrive\\Desktop\\codWW\\inicio.jpeg");
        JLabel lblImagen = new JLabel(new ImageIcon(
            image.getImage().getScaledInstance(this.getWidth(), this.getHeight(), Image.SCALE_SMOOTH)
        ));
        lblImagen.setBounds(0, 0, this.getWidth(), this.getHeight());
        layeredPane.add(lblImagen, Integer.valueOf(1)); // Fondo en la capa más baja
        
        // titulo
        JLabel lbltitulo = new JLabel("Bienvenidos al Supermercado");
        lbltitulo.setBounds(90, 10, 330, 50);
        lbltitulo.setBackground(new Color(0, 170, 228));
        lbltitulo.setOpaque(true);
        lbltitulo.setFont(new Font("Comic Sans MS", 2, 24));
        layeredPane.add(lbltitulo, Integer.valueOf(2));
        
        // ingresar cliente 
        JLabel lblIngresarCliente = new JLabel("Cliente:");
        lblIngresarCliente.setBounds(60, 100, 70, 40);
        lblIngresarCliente.setBackground(new Color(255, 100, 100));
        lblIngresarCliente.setOpaque(true);
        lblIngresarCliente.setFont(new Font("Comic Sans MS", 2, 18));
        layeredPane.add(lblIngresarCliente, Integer.valueOf(2));
        
        // cliente datos y textfield
        JPanel panelClienteDatos = new JPanel();
        panelClienteDatos.setBounds(30, 140, 160, 80);
        panelClienteDatos.setBackground(new Color(255, 100, 100));
        panelClienteDatos.setOpaque(true);
        layeredPane.add(panelClienteDatos, Integer.valueOf(2));
        
        JLabel nombre = new JLabel("nombre:");
        nombre.setBounds(35, 145, 80, 40);
        layeredPane.add(nombre, Integer.valueOf(3));
        
        JTextField campoNombre = new JTextField();
        campoNombre.setBounds(95, 155, 90, 20);
        layeredPane.add(campoNombre, Integer.valueOf(3));
        
        JLabel id = new JLabel("id:");
        id.setBounds(35, 180, 80, 40);
        layeredPane.add(id, Integer.valueOf(3));
        
        JTextField campoId = new JTextField();
        campoId.setBounds(95, 190, 90, 20);
        layeredPane.add(campoId, Integer.valueOf(3));
        
        // Botón ingresar 
        JButton btnIngresarCliente = new JButton("Ingresar");
        btnIngresarCliente.setBounds(30, 220, 90, 20);
        btnIngresarCliente.addActionListener(e -> {
            Cliente cliente1 = new Cliente(campoNombre.getText(), Integer.parseInt(campoId.getText()));
            abrirVentanaPrincipal(cliente1);
        });

        layeredPane.add(btnIngresarCliente, Integer.valueOf(3));
        
        // ingresar empleado
        JLabel lblIngresarEmpleado = new JLabel("Empleado:");
        lblIngresarEmpleado.setBounds(340, 100, 90, 40);
        lblIngresarEmpleado.setBackground(new Color(254, 254, 150));
        lblIngresarEmpleado.setOpaque(true);
        lblIngresarEmpleado.setFont(new Font("Comic Sans MS", 2, 18));
        layeredPane.add(lblIngresarEmpleado, Integer.valueOf(2));
        
        
        
        // empleado datos y textfield
        JPanel panelEmpleadoDatos = new JPanel();
        panelEmpleadoDatos.setBounds(310, 140, 160, 120);
        panelEmpleadoDatos.setBackground(new Color(254, 254, 150));
        panelEmpleadoDatos.setOpaque(true);
        layeredPane.add(panelEmpleadoDatos, Integer.valueOf(2));
        
        JLabel nombreEmpleado = new JLabel("nombre:");
        nombreEmpleado.setBounds(315, 145, 80, 40);
        layeredPane.add(nombreEmpleado, Integer.valueOf(3));
        
        JTextField campoNombreEmpleado = new JTextField();
        campoNombreEmpleado.setBounds(375, 155, 90, 20);
        layeredPane.add(campoNombreEmpleado, Integer.valueOf(3));
        
        JLabel idEmpleado = new JLabel("id:");
        idEmpleado.setBounds(315, 180, 80, 40);
        layeredPane.add(idEmpleado, Integer.valueOf(3));
        
        JTextField campoIdEmpleado = new JTextField();
        campoIdEmpleado.setBounds(375, 190, 90, 20);
        layeredPane.add(campoIdEmpleado, Integer.valueOf(3));
        
        JLabel cargo = new JLabel("cargo:");
        cargo.setBounds(315, 215, 80, 40);
        layeredPane.add(cargo, Integer.valueOf(3));
        
        JTextField campoCargo = new JTextField();
        campoCargo.setBounds(375, 225, 90, 20);
        layeredPane.add(campoCargo, Integer.valueOf(3));
        
        // boton ingresar empleado
        JButton btnIngresarEmpleado = new JButton("Ingresar");
        btnIngresarEmpleado.setBounds(310, 260, 90, 20);
        btnIngresarEmpleado.addActionListener(e -> new Empleado(campoNombreEmpleado.getText(), Integer.parseInt(campoIdEmpleado.getText()), campoCargo.getText()));
        layeredPane.add(btnIngresarEmpleado, Integer.valueOf(3));
        
      
       
        this.setVisible(true);
    }


    private void abrirVentanaPrincipal(Cliente cliente) {
    VentanaPrincipal ventanita = new VentanaPrincipal();
    ventanita.setCliente(cliente);
    ventanita.setVisible(true);
}
    
}
